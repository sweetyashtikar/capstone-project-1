const data = {
  products: [
    {
      id: "1",
      name: "Tomato Basil Italian Pizza",
      price: 450,
      image:
        "https://cdn.pixabay.com/photo/2017/02/15/10/57/pizza-2068272__480.jpg",
    },

    {
      id: "2",
      name: "Bombay-Pizza",
      price: 550,
      image:
        "https://cdn.pixabay.com/photo/2020/06/08/16/49/pizza-5275191__340.jpg",
    },
    {
      id: "3",
      name: " Sicillia-Pizza",
      price: 450,
      image:
        "https://cdn.pixabay.com/photo/2016/11/29/13/02/cheese-1869708__340.jpg",
    },
    {
      id: "4",
      name: " Cheese Burger",
      price: 250,

      image:
        "https://cdn.pixabay.com/photo/2020/03/21/11/17/burger-4953465__340.jpg",
    },
    {
      id: "5",
      name: " Mushroom-Burger",
      price: 400,
      image:
        "https://cdn.pixabay.com/photo/2016/03/26/23/19/hamburger-1281855__340.jpg",
    },
    {
      id: "6",
      name: " Veg-Burger",
      price: 200,
      image:
        "https://cdn.pixabay.com/photo/2014/10/23/18/05/burger-500054__340.jpg",
    },
  ],
};
export default data;
